#pragma once

#include "lab_extra/shadow_mapping/shadow_mapping.h"
#include "lab_extra/compute_shaders/compute_shaders.h"
#include "lab_extra/compute_shaders_ext/compute_shaders_ext.h"
#include "lab_extra/tessellation_shader/tessellation_shader.h"
#include "lab_extra/basic_text/basic_text.h"
